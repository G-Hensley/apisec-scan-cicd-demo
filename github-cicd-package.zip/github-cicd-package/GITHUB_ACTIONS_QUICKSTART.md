# APIsec GitHub Actions Integration — Quickstart

This guide walks through wiring the APIsec CI/CD Integration into a GitHub Actions workflow so that every push and pull request runs an API security scan, and the build fails when High or Critical findings are detected.

The workflow file in this package (`.github/workflows/apisec-scan.yml`) is production-ready. The steps below cover credential setup, threshold configuration, and merge-gate enforcement.

---

## How It Works

On every pipeline run, the integration:

1. Triggers an API security scan against your registered APIsec application and instance.
2. Monitors the scan in real time (polls every 5 seconds, up to one hour).
3. Reports vulnerabilities grouped by severity and CVSS score.
4. Exits with code `0` (pass) or `1` (fail) based on your configured thresholds, passing or failing the GitHub Actions job accordingly.

The scan runs entirely in APIsec's platform — the GitHub runner only orchestrates it. No API source code is uploaded; the scanner hits the registered target URL of your application instance.

---

## Prerequisites

- An APIsec account with at least one application and instance configured.
- A registered target URL and OpenAPI spec for the application/instance you want to scan.
- GitHub repository with Actions enabled.
- Repository or organization admin access to configure secrets and variables.

---

## Step 1: Obtain Your APIsec Credentials

Three values are required. Grab them from the APIsec platform:

**Application ID** and **Instance ID** — embedded in the URL when you open your application in the APIsec dashboard:

```
https://<your-tenant>.apisecapps.com/application/<APPLICATION_ID>/instance/<INSTANCE_ID>
```

**Access Token** — open the **API Token** menu in your APIsec account settings and copy (or generate) your token.

Store all three as GitHub secrets in the next step. Do not paste them into pipeline files or commit them to source control.

---

## Step 2: Add Secrets to GitHub

Navigate to **Repository → Settings → Secrets and variables → Actions → New repository secret** and add:

| Secret name | Value |
|---|---|
| `APISEC_APPLICATION_ID` | Application ID from Step 1 |
| `APISEC_INSTANCE_ID` | Instance ID from Step 1 |
| `APISEC_ACCESS_TOKEN` | Access token from Step 1 |

For organization-wide deployment, define these as **organization secrets** with repository-level access controls. This centralizes credential management and eliminates per-repository secret configuration.

---

## Step 3: Add the Workflow File

Copy `.github/workflows/apisec-scan.yml` from this package into the same path in your repository. Commit and push. The scan will run on your next push or pull request to `main`.

The workflow is configured to trigger on:

- Any push to `main` or any `release/**` branch
- Any pull request targeting `main`

Adjust the `on:` block at the top of the file if you use different branch conventions.

### Note on Container Architecture

The workflow includes a `docker/setup-qemu-action@v3` step before the scan run. This is required because `daveapisec/cicd:5.2.0` is published as a `linux/arm64` image, while GitHub's `ubuntu-latest` runners are `linux/amd64`. The QEMU step registers arm64 binfmt handlers on the runner so the scanner can execute under emulation; the `--platform linux/arm64` flag on `docker run` makes the architecture selection explicit.

No additional configuration is required on your side — the step works out of the box on hosted GitHub runners. The trade-off is added wall-clock time per scan run versus running a native-architecture image; for typical scans this is on the order of a few minutes. If you run on self-hosted arm64 runners, the QEMU step is harmless (no-ops) but can be removed.

---

## Step 4: Configure Threshold Variables (Optional but Recommended)

The workflow ships with defaults that match a "block High and Critical findings" policy:

- `INPUT_FAIL_ON_SEVERITY_THRESHOLD=8` — only findings at CVSS 8.0 or higher count toward failure.
- `INPUT_FAIL_ON_ERROR_THRESHOLD=0` — any qualifying finding fails the build (zero tolerance).

To override these without editing the workflow file, add **Variables** (not secrets) under **Settings → Secrets and variables → Actions → Variables**:

| Variable name | Example value | Effect |
|---|---|---|
| `APISEC_SEVERITY_THRESHOLD` | `8` | Minimum CVSS score to count toward failure |
| `APISEC_ERROR_THRESHOLD` | `0` | Maximum qualifying findings permitted |

### Severity Threshold Reference

| Value | Effect |
|---|---|
| `10` | Fail only on CVSS 10.0 (Critical) findings |
| `8` | Fail on High and Critical findings — **recommended baseline** |
| `5` | Fail on Medium, High, and Critical findings — strict posture |
| `0` | Fail on any finding regardless of severity |

### Error Threshold Reference

| Value | Effect |
|---|---|
| `0` | Zero tolerance — any qualifying finding fails the build |
| `1`–`N` | Permits up to N qualifying findings; fails on N+1 |
| *(unset)* | Count-based failure disabled — scans always pass |

### Gradual Rollout

For teams with existing vulnerability debt, set `APISEC_ERROR_THRESHOLD` to your current qualifying-finding count as a baseline, then reduce it over successive sprints as remediation progresses. This lets you ratchet the gate tighter over time without flooding teams with day-one failures.

---

## Step 5: Enforce as a Required Status Check

To block merges when the scan fails:

1. **Settings → Branches → Branch protection rules**
2. Add or edit the rule for `main`.
3. Enable **Require status checks to pass before merging**.
4. Search for and select `APIsec CI/CD Integration` (the job name in the workflow).

Once this is in place, any pull request with qualifying findings at or above your thresholds cannot be merged until the findings are remediated or the thresholds are adjusted.

---

## Step 6: Multi-Environment Configuration (Optional)

For repositories deployed to multiple environments (staging, production), use environment-scoped secrets so each deployment stage scans the correct APIsec instance:

1. **Settings → Environments** → create environments (e.g., `staging`, `production`).
2. Add environment-specific APIsec secrets to each.
3. Reference the environment in your workflow:

```yaml
jobs:
  apisec-scan:
    environment: production
    runs-on: ubuntu-latest
    steps:
      - name: Run APIsec CI/CD Integration
        run: |
          docker run --rm \
            -e INPUT_APPLICATION_ID="${{ secrets.APISEC_APPLICATION_ID }}" \
            ...
```

---

## Reading the Output

When the scan runs, the job log shows:

```
Initiating scan...
Scan ID: <uuid>
Status: In Progress (0:00:15 elapsed)
...
Scan ID: <uuid> Complete   65 secs   Polling ended. Scan complete: True

Vulnerability Counts
--------------------
Critical           3
Medium             3
--------------------

Score Counts
------------
6.0        1
5.0        2
10.0       3
------------

Total Errors at Severity 8.0 or higher: 0
API scan passed! Number of ERRORS: 0 (Within threshold of 0)
```

- **Vulnerability Counts** — all findings grouped by severity rating.
- **Score Counts** — findings by exact CVSS score, useful for diagnosing threshold misalignment.
- **Total Errors at Severity N or higher** — findings that count toward the pass/fail decision.
- **API scan passed / failed** — the pipeline-level outcome.

See `SAMPLE_OUTPUT.md` for real example runs.

---

## Exit Codes

| Code | Meaning |
|---|---|
| `0` | Scan completed; findings are within configured thresholds (pipeline passes) |
| `1` | Scan completed; findings exceed thresholds (pipeline fails) |

Any non-zero exit code fails the GitHub Actions job, which blocks merges when the required status check is enforced (Step 5).

---

## Where to View Results

Three places:

1. **GitHub Actions tab** — expand the `APIsec CI/CD Integration` job to see the scan summary.
2. **APIsec dashboard** — click through to your application for the full scan record, affected endpoints, and remediation guidance.
3. **Status checks on the pull request** — the job appears in the PR checks list and blocks merge when failed.

---

## When a Build Fails

1. Check the job log for the Vulnerability Summary table.
2. Note the count of findings above your severity threshold.
3. Log in to the APIsec dashboard to view the full findings list with remediation guidance.
4. Remediate, push a fix, and re-run the pipeline.

---

## Support

Questions or issues: **support@apisec.ai**, or reply directly to the email this package came attached to.
