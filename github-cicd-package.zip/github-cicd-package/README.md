# APIsec CI/CD Integration — GitHub Actions Package

This package contains everything needed to add the APIsec API security scan to a GitHub Actions pipeline, so that every push and pull request runs a scan and the build fails when High or Critical findings are detected.

It's built around the requirement of blocking API releases that contain Critical or High severity findings — the scan runs as a required status check, and pull requests cannot merge while qualifying findings are open.

---

## What's in This Package

| File | Purpose |
|---|---|
| `GITHUB_ACTIONS_QUICKSTART.md` | Start here. Step-by-step setup: credentials, secrets, thresholds, branch protection. |
| `.github/workflows/apisec-scan.yml` | Drop-in GitHub Actions workflow. Copy to the same path in your repository. |
| `SAMPLE_OUTPUT.md` | Annotated real example run showing finding detection and how the build gate fails when thresholds are exceeded. |
| `README.md` | This file. |

---

## Suggested Reading Order

1. **`GITHUB_ACTIONS_QUICKSTART.md`** — walks through the 5 setup steps end-to-end.
2. **`SAMPLE_OUTPUT.md`** — see what a scan looks like in the job log before you wire it up.
3. **`.github/workflows/apisec-scan.yml`** — review the workflow; copy it into your repo when ready.

---

## Defaults

The workflow ships with thresholds that implement a "block High and Critical findings" policy out of the box:

- `INPUT_FAIL_ON_SEVERITY_THRESHOLD=8` — count findings at CVSS 8.0 and above.
- `INPUT_FAIL_ON_ERROR_THRESHOLD=0` — any qualifying finding fails the build.

Both are overridable via GitHub Actions **Variables** without editing the workflow file. See Quickstart Step 4.

---

## Prerequisites Recap

- APIsec account with an application and instance configured.
- GitHub repository admin access (to add secrets, variables, and branch protection rules).
- Three credential values from the APIsec dashboard: Application ID, Instance ID, Access Token.

---

## Support

Questions during setup: reply to the email this package came attached to, or contact **support@apisec.ai**.
