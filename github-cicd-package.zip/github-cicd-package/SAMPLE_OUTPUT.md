# Sample Output — APIsec GitHub Actions Integration

A real run from a GitHub Actions pipeline against a test API with known vulnerabilities, executed using the same workflow in this package (`.github/workflows/apisec-scan.yml`).

The test API was a deliberately vulnerable FastAPI target with 4 Critical (CVSS 10.0) and 3 Medium (CVSS 5.0–6.0) findings — seven total.

---

## Failing Build — Finding Detection + Gate Enforcement

**Configuration**

- `INPUT_FAIL_ON_SEVERITY_THRESHOLD=5` — count findings at CVSS 5.0 or higher
- `INPUT_FAIL_ON_ERROR_THRESHOLD=1` — permit up to 1 qualifying finding; fail on 2+

**Output**

```
Scan ID: 019db6be-21e4-7da6-8876-9858638ec097 Complete   64 secs   Polling ended. Scan complete: True

Vulnerability Counts
--------------------
Critical           4
Medium             3
--------------------

Score Counts
------------
6.0        1
5.0        2
10.0       4
------------

Total Errors at Severity 5.0 or higher: 7
API scan failed! Number of ERRORS: 7 (Exceeded threshold of 1)
```

**What to notice**

- All 7 findings are counted against the severity threshold: 4 Criticals at CVSS 10.0 and 3 Mediums at CVSS 5.0–6.0.
- The error threshold of 1 permits a single qualifying finding; 7 exceeds that, so the build fails.
- `API scan failed!` causes the job to exit with code 1. When the branch protection rule from Quickstart Step 5 is in place, this blocks the pull request merge until the findings are remediated or the thresholds are adjusted.

---

## Applying to Your Configuration

This sample was run at `SEVERITY_THRESHOLD=5` and `ERROR_THRESHOLD=1` to demonstrate detection across all severities. The workflow's documented default is stricter:

- `FAIL_ON_SEVERITY_THRESHOLD=8` — count only High (CVSS 7.0–8.9) and Critical (9.0–10.0) findings
- `FAIL_ON_ERROR_THRESHOLD=0` — zero tolerance; any qualifying finding fails

Against this same test API, that default configuration would count the 4 Critical findings and fail immediately (4 exceeds threshold of 0). Medium findings would still surface in the **Vulnerability Counts** table for visibility, but would not count toward failure.

---

## Using This Sample

- Confirms the integration detects and counts findings by CVSS score.
- Confirms a failing scan exits with code 1, which fails the GitHub Actions job and — with the required status check from Quickstart Step 5 — blocks the merge.
- Once verified against your application, tune the thresholds (Quickstart Step 4) to match your release policy and enable the required status check.
